package com.fot.canteenapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CanteenappApplicationTests {

	@Test
	void contextLoads() {
	}

}
