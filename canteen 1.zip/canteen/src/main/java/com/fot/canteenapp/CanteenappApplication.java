package com.fot.canteenapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class CanteenappApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(CanteenappApplication.class, args);
	}

}
